const CACHE='controle-estudos-v5-cache';
const CORE=['./','./index.html','./manifest.webmanifest','./service-worker.js','./icons/icon-192.png','./icons/icon-512.png'];
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(c=>c.addAll(CORE)).then(()=>self.skipWaiting())));
self.addEventListener('activate',event=>event.waitUntil(self.clients.claim()));
self.addEventListener('fetch',event=>{
  const url=new URL(event.request.url);
  if(event.request.method!=='GET')return;
  event.respondWith(
    caches.match(event.request).then(cached=>cached||fetch(event.request).then(resp=>{
      if(resp.ok || resp.type==='opaque'){
        const copy=resp.clone();caches.open(CACHE).then(c=>c.put(event.request,copy));
      }
      return resp;
    }).catch(()=>caches.match('./index.html')))
  );
});
