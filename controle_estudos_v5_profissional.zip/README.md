# Controle de Estudos V5 — PWA

Versão profissional instalável como aplicativo (PWA).

## Principais melhorias
- Instalação no Android/Windows/macOS por navegador compatível.
- Funcionamento offline para o aplicativo e os dados já carregados.
- Service Worker com cache local.
- Dados persistidos no aparelho.
- Botão de instalação quando o navegador disponibilizar a instalação.
- Importador de PDF mais robusto: identifica cabeçalhos em caixa alta e itens numerados, inclusive quando o PDF junta vários elementos na mesma linha.
- Leitor PDF tenta usar uma cópia local primeiro e, como fallback, PDF.js por CDN. Depois de abrir o app online uma vez, o Service Worker pode armazenar recursos acessados para uso posterior offline.
- Cronômetro, revisão adaptativa, índice de preparação, caderno de erros e modo reta final mantidos.

## Como instalar no Android
1. Publique esta pasta em um endereço HTTPS (GitHub Pages, Netlify, Vercel, servidor próprio etc.).
2. Abra o endereço no Chrome/Edge do celular.
3. Aguarde a página carregar totalmente uma vez com internet.
4. Toque em `📲 Instalar` dentro do app, quando aparecer, ou use o menu do navegador → `Adicionar à tela inicial` / `Instalar aplicativo`.
5. Abra pelo ícone criado. O app passa a abrir em modo de aplicativo.
6. Teste o modo offline ativando o modo avião e reabrindo o app.

## Importante sobre PDF offline
O núcleo do aplicativo funciona offline. O leitor de PDF tenta primeiro um arquivo local e depois o CDN. Nesta build não foi possível embutir o pacote do PDF.js completo; por isso o ideal é abrir o app uma vez com internet e deixar o navegador fazer o cache do componente PDF. Um PDF escaneado/imagem continua exigindo OCR.

## Como instalar no computador para teste local
Não abra o `index.html` com duplo clique (`file://`), porque Service Worker e alguns recursos de módulos não funcionam assim. Rode um servidor local, por exemplo:

python -m http.server 8080

Depois abra `http://localhost:8080`.

## Próximo salto
- Login e sincronização em nuvem.
- Banco de questões por banca.
- PWA + empacotamento Android (APK/AAB) com Capacitor.
- Notificações de revisão.
- Importação genérica de edital com hierarquia Matéria > Tópico > Subtópico.
