# GUIA DE INSTALAÇÃO — CONTROLE DE ESTUDOS

## Android
1. Publique a pasta em um endereço HTTPS, como GitHub Pages, Netlify ou Vercel.
2. Abra o endereço no Chrome do celular.
3. Carregue o aplicativo uma vez com internet.
4. Toque em `📲 Instalar` quando aparecer, ou no menu do Chrome use `Adicionar à tela inicial`/`Instalar aplicativo`.
5. Abra pelo ícone criado.
6. Depois de carregar uma vez, teste o modo offline ativando o modo avião.

## GitHub Pages (gratuito)
1. Crie um repositório no GitHub.
2. Envie `index.html`, `manifest.webmanifest`, `service-worker.js`, a pasta `icons/` e este guia.
3. Vá em `Settings` → `Pages`.
4. Escolha `Deploy from a branch`, branch `main`, pasta `/root` e salve.
5. Abra no celular o endereço HTTPS informado pelo GitHub.

## Computador
Na pasta do aplicativo:

`python -m http.server 8080`

Depois abra `http://localhost:8080`.

## Por que não abrir por duplo clique?
O modo `file://` não fornece a origem HTTP/HTTPS necessária para vários recursos de PWA, especialmente Service Worker.

## Offline e PDF
O aplicativo tenta usar o leitor PDF local, depois o cache e, por último, o PDF.js online. Para primeira leitura de PDF totalmente offline, a próxima build deve embutir o PDF.js completo.

## O que a V5 entrega
- PWA instalável.
- Dados locais persistentes.
- Offline para recursos já carregados.
- Importador PDF mais robusto e genérico.
- Cronômetro real.
- Revisão adaptativa.
- Índice de preparação.
- Caderno de erros.
- Priorização de estudos.
- Modo reta final.
- Backup.
